package com.joshua.StockManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
